//
//  ViewController.swift
//  Act1Samantha
//
//  Created by SAMUEL HERRERA on 26/01/24.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var Roller: UIButton!
    @IBOutlet weak var RandomNumber: UILabel!
    
    @IBOutlet weak var Mensaje: UILabel!
    @IBOutlet weak var textField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        textField.delegate = self
    }
    
    
    // Método que restablece los valores del mensaje, del fondo y del símbolo "?"
    func resetValues() {
        view.backgroundColor = UIColor.white
        Mensaje.text = ""
        RandomNumber.text = "?"
    }
    
    // Método llamado cuando se inicia la edición en el textField
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        // Borrar el contenido del textField
        textField.text = ""
        resetValues()
        return true
    }
    
    
    @IBAction func rollButtonClicked(_ sender: UIButton) {
        // Generar un número aleatorio entre 1 y 6
        let randomNumber = Int.random(in: 1...6)
        
        // Obtener el número ingresado en el textField
        if let enteredNumber = Int(textField.text ?? "") {
            // Verificar si el número ingresado coincide con el número aleatorio
            if enteredNumber == randomNumber {
                // Cambiar el fondo del view a verde si coincide
                view.backgroundColor = UIColor.green
                Mensaje.text = "¡Felicidades, has tenido el número ganador!"
            } else {
                // Cambiar el fondo del view a rojo si no coincide
                view.backgroundColor = UIColor.red
                Mensaje.text = "Lo siento, has perdido. ¡Suerte para la próxima!"
            }
        } else {
            // Cambiar el fondo del view a rojo si no se ingresó un número válido
            view.backgroundColor = UIColor.red
            Mensaje.text = "Por favor, ingresa un número válido."
        }
        
        // Actualizar el texto del Label con el número generado
        RandomNumber.text = "\(randomNumber)"
        
        // Desactivar la edición del textField
        textField.resignFirstResponder()
        
        // Desmarcar el botón después de hacer clic
        sender.isSelected = false
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        // Verificar si la cadena de reemplazo contiene solo números del 1 al 6
        let allowedCharacterSet = CharacterSet(charactersIn: "123456")
        let replacementStringCharacterSet = CharacterSet(charactersIn: string)
        let isNumeric = replacementStringCharacterSet.isSubset(of: allowedCharacterSet)
        
        // Verificar si la longitud total después del cambio es 1 o menos (para evitar que se ingresen más de un carácter)
        let newLength = (textField.text?.count ?? 0) + string.count - range.length
        let isLengthValid = newLength <= 1
        
        // Restaurar el color de fondo original del view
        view.backgroundColor = UIColor.white
        
        return isNumeric && isLengthValid
    }
}
